


var button = document.getElementById('three');
    	button.addEventListener('click', function() {
    		var word = document.getElementById('two').value;
    		var count = word.length;
    		var outputDiv = document.getElementById('output');
    		outputDiv.innerHTML = `<h2>${count}</h2>`
    	});